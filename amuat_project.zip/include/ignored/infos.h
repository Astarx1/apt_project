#define API_DESCRIPTION "Ranking API"
#define API_VERSION "0.1"