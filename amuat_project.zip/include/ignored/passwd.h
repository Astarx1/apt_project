#define MYSQL_USER "root"
#define MYSQL_PWD "root"
#define MYSQL_DB "goranking" 